import os
import pickle
import numpy as np
import undetected_chromedriver as uc
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, ElementNotInteractableException , ElementClickInterceptedException
from selenium.common.exceptions import TimeoutException
from time import sleep
import pandas as pd
import openpyxl 
import re
from fuzzywuzzy import fuzz , process 

browser = uc.Chrome(
	options=webdriver.ChromeOptions(),
)
browser.maximize_window()

def login(username, password):
	#options.add_argument('proxy-server=106.122.8.54:3128')
	#options.add_argument(r'--user-data-dir=C:\Users\Admin\AppData\Local\Google\Chrome\User Data\Default')
	
	browser.get('https://sellercenter.lazada.vn/apps/seller/login?redirect_url=https://sellercenter.lazada.vn/apps/campaign/master/list')

	browser.find_element(By.ID, 'account').send_keys(username)
	browser.find_element(By.ID, 'password').send_keys(password)

	sleep(1.5)

	browser.find_element(By.XPATH,("//button[@type='submit']")).click()
	
def getCookie():
	browser.get('https://sellercenter.lazada.vn/apps/campaign/master/list')
	cookies = pickle.load(open("cookies.pkl", "rb"))
	for cookie in cookies:
		browser.add_cookie(cookie)

def setCookie():
	try:
		WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'next-list-items')))
		# lấy cookie và lưu vào file cookies.pkl
		pickle.dump(browser.get_cookies() , open("cookies.pkl", "wb"))
	except TimeoutException:
		print("Loading took too much time!")

def getCampaigns():
	links = []
	titles = []
	times = []

	elem_links = browser.find_elements(By.CSS_SELECTOR , ".next-list-items [href]")
	links = [link.get_attribute('href') for link in elem_links]
	
	elem_titles = browser.find_elements(By.CSS_SELECTOR , ".banner .title")
	titles = [title.text for title in elem_titles]
	
	elem_times = browser.find_elements(By.CSS_SELECTOR , ".banner .time-range-item")
	times = [time.text for time in elem_times]
	sleep(1)
	print(f"links: {links}\ntitles: {titles}\ntimes: {times}")
	
	# Create and add data in data frame
	df1 = pd.DataFrame(list(zip(titles, times, links)), columns = ['titles', 'times', 'links'])
	# Create a new columns index, if want to concat this data frame to another data frame
	df1['index_']= np.arange (1, len(df1) + 1)
	# new_df1['time'] = df1['time'].str.replace('\n', '')
	print(df1)
	sleep(1)
	print(f' \n CHECKING : { links[0] }')
	return df1

def df1_excel(df1):
	path = "excel"
	if not os.path.exists(path):
		# The Excel file does not exist, so create it
		os.makedirs(path)
		path = os.path.join(path, "test.xlsx")
		workbook = pd.ExcelWriter(path, engine='openpyxl', mode='w')
		df1.to_excel(workbook, sheet_name="campaign", index=False)
		# workbook.save(path)
		workbook.close()
		
	else :
		path = os.path.join(path, "test.xlsx")
		df1 = pd.read_excel(path, sheet_name="campaign")
		
		# Get the new data
		new_data = getCampaigns()

		# Concatenate the new data to the existing data
		df_concat = pd.concat([df1, new_data], ignore_index=True)

		# Save the concatenated data to the Excel file
		df_concat.to_excel(path, sheet_name="campaign", index=False)
		
# execute in main , to get voucherLink
def gateVoucher_links(voucherLink):
	browser.get(voucherLink)
	sleep(1.5)
	# using a set instead of a list to store the vouchers_links.
	# This ensures that there are no duplicate values in the set.
	vouchers_links = set()
	
	try:
		# The "Tiếp theo" button is present click else pass it
		tab_gateVoucher = browser.find_element(By.XPATH, ("//div[text()='Cổng voucher']"))
		tab_gateVoucher.click()
		sleep(1)
	
		vouchers_links.update(
		[voucher.get_attribute("href")
			for voucher in browser.find_elements(By.CSS_SELECTOR, ".aplus-auto-exp [href]")])

		sleep(1)
	
		#if it is no more next page break out the try
		next_pagination = browser.find_element(By.XPATH, ("//span[contains(text(),'Tiếp theo')]"))
		while True:
			try:
				next_pagination.click()
				sleep(1)
				vouchers_links.update(
						[voucher.get_attribute("href")
							for voucher in browser.find_elements(By.CSS_SELECTOR, ".aplus-auto-exp [href]")])
				
				sleep(1)
				
			except ElementNotInteractableException :
				print("No more next page button!")

			else :
				break
		
	except NoSuchElementException :
		print('\n This campaign_links has no tab Cổng Voucher, so pass it ')
		
	else:
		pass
	
	df2 = pd.DataFrame(list(zip(vouchers_links)), columns=["vouchers_links"])
	# df2 = df2.drop_duplicates()
	df2["index_"] = np.arange(1, len(df2) + 1)

	print(f"\n Running voucherLink all gateVoucher_links: \n {voucherLink}")
	print(f"\n This campaign_links has {len(vouchers_links)} links.")

	print(f'\n THIS IS DataFrame df2 : \n { df2 }')
	print(f'\n THIS IS vouchers_links in df2 : \n {vouchers_links}')
	print('---------------------------------------------------------------------------')
	return df2

# put df2 to excel
def df2_excel(concatenate_df2):
	path = os.path.join("excel", "gateVoucherLinks.xlsx")
	workbook = pd.ExcelWriter(path, engine='openpyxl')
	
	concatenate_df2 = pd.concat(concatenate_df2, ignore_index=True)
	
	concatenate_df2.to_excel(workbook, sheet_name="gateVoucherLinks", index=False,)
	
	workbook.save()
	return concatenate_df2

def joinNow(link):
	# count = 0
	browser.get(link)
	print(f'\n THIS IS def joinNow open link : \n { link } \n')
	sleep(1)
	elem_strs = browser.find_elements(By.CSS_SELECTOR , ".rules-info")
	strs = [str.text for str in elem_strs]
	sleep(1)
	# print(f' \n THIS IS strs :\n {strs} \n ')
	

	# Find the two strings
	str1 = "Mức % giảm voucher ≥ 20%"
	str2 = "Giá trị đơn hàng tối thiểu ≥ 150k"
	# str3 = 'Voucher có mức giảm ≥20%'
	# str4 = 'Giá trị đơn phải được cài đặt tối thiểu 1đ đến ≤1.500.000đ'
	
	# Lấy các kết quả khớp với str1 và str2
	results1 = process.extract(str1, strs, scorer=fuzz.partial_ratio, limit=None)
	results2 = process.extract(str2, strs, scorer=fuzz.partial_ratio, limit=None)
	# count = 0
	# Chỉ in kết quả nếu điểm số của cả str1 và str2 lớn hơn 90
	# while count < len(results1) and count < len(results2):
	# Tạo biến để lưu trữ kết quả
	found_results = []

	# Chỉ in kết quả nếu điểm số của cả str1 và str2 lớn hơn 80
	for result1, result2 in zip(results1, results2):
		if result1[1] > 80 and result2[1] > 80:
			found_results.extend(result1[1], result2[1])

	# In kết quả
	for idx , found_result in enumerate ( found_results) :
		print(f"this is found_result : {idx , found_result}")
	# return count
	
		
	# print(results)
	# # Lấy điểm so khớp tương đối giữa hai chuỗi
	# score1 = fuzz.token_sort_ratio(str1, strs)
	# score2 = fuzz.token_sort_ratio(str2, strs)
	# sleep(1)
	# # Lấy điểm so khớp tương đối cao nhất
	# max_score = max(score1, score2)

	# # Kiểm tra xem điểm so khớp tương đối có lớn hơn 80 không
	# if max_score > 80:
	# 	print("Cả hai chuỗi đều được tìm thấy")
	# 	count +=1

	# else:
	# 	print("no")

	# print(count)
	
	
"""
# Check if the str1 and str2 are in strs
	if str1 in strs :
		print('found str1')
	elif str2 in strs :
		print('found str2')
	# elif str3 in strs :
		print('found str3')
	# elif str4 in strs :
		print('found str4')
	
	else:
		print('str1 - str2 are not in strs')
"""
	

	# Check if any of the strings contain any of the texts
	# texts = ["20%", "Voucher có mức giảm ≥20%", "Mức giảm giá phải cài đặt ≥40k"]
	# Check for the desired texts using a regular expression
	# for str in strs:
	# 	matches = re.search(r"Mức % giảm voucher ≥ 20% and Giá trị đơn hàng tối thiểu ≥ 150k|Voucher có mức giảm ≥10% and Giá trị đơn phải được cài đặt tối thiểu 1đ đến ≤1.500.000đ|Mức giảm giá phải cài đặt ≥40k and 1đ đến ≤1.500.000đ",str)
	# 	if matches:
	# 		# Click the button
	# 		browser.find_element(By.XPATH, ("//button[@type='button']")).click()
	# 		print('\n \n found strs')
	# 		# print(f'\n The number of times the texts were found : {len(matches)}')





if __name__ == '__main__':
	# if os.path.isfile('./cookies.pkl'):
	# 	getCookie()
	# else:
	login('Pimoni94@gmail.com', 'Thaothao090311@')
	setCookie()
	
	df1 = getCampaigns()
	df1_excel(df1)

# take all the df1["links"] in getCampaigns() make new variable to make a excel file
	concatenate_df2 = []

	#loop through df1["links"] to craw data for df2
	for voucherLink in df1["links"]:
		df2 = gateVoucher_links(voucherLink)
		concatenate_df2.append(df2)
	
	concatenate_df2 = df2_excel(concatenate_df2)
	
	# joinNow_link = []
	for link in concatenate_df2["vouchers_links"]:
		df_2 = joinNow(link)
		# joinNow_link.append(df_2)
	
		# joinNow(link)
	print(f"\n joinNow len : {len(link)} ")
	
	

	